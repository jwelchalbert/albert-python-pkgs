from albert.api.paths.api_v3_predictions_parent_id.patch import ApiForpatch


class ApiV3PredictionsParentId(
    ApiForpatch,
):
    pass
