from albert.api.paths.api_v3_productdesign_search.get import ApiForget


class ApiV3ProductdesignSearch(
    ApiForget,
):
    pass
