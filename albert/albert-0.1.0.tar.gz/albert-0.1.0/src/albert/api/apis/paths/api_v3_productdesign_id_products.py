from albert.api.paths.api_v3_productdesign_id_products.post import ApiForpost


class ApiV3ProductdesignIdProducts(
    ApiForpost,
):
    pass
