from albert.api.paths.api_v3_productdesign_inventories_id.get import ApiForget
from albert.api.paths.api_v3_productdesign_inventories_id.put import ApiForput


class ApiV3ProductdesignInventoriesId(
    ApiForget,
    ApiForput,
):
    pass
