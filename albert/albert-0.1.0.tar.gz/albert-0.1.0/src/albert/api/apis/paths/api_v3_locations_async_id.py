from albert.api.paths.api_v3_locations_async_id.get import ApiForget
from albert.api.paths.api_v3_locations_async_id.put import ApiForput


class ApiV3LocationsAsyncId(
    ApiForget,
    ApiForput,
):
    pass
