from albert.api.paths.api_v3_reports_suggest.get import ApiForget


class ApiV3ReportsSuggest(
    ApiForget,
):
    pass
