from albert.api.paths.api_v3_productdesign_id_values.patch import ApiForpatch


class ApiV3ProductdesignIdValues(
    ApiForpatch,
):
    pass
