from albert.api.paths.api_v3_reports_inventory_equipment_usage.get import ApiForget


class ApiV3ReportsInventoryEquipmentUsage(
    ApiForget,
):
    pass
