from albert.api.paths.api_v3_predictions_health.get import ApiForget


class ApiV3PredictionsHealth(
    ApiForget,
):
    pass
