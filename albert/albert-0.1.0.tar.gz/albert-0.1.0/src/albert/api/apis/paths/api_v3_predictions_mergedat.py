from albert.api.paths.api_v3_predictions_mergedat.post import ApiForpost


class ApiV3PredictionsMergedat(
    ApiForpost,
):
    pass
