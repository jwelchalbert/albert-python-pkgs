from albert.api.paths.api_v3_predictions_mergedac.post import ApiForpost


class ApiV3PredictionsMergedac(
    ApiForpost,
):
    pass
