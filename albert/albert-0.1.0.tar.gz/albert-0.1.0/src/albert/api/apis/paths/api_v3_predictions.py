from albert.api.paths.api_v3_predictions.get import ApiForget
from albert.api.paths.api_v3_predictions.post import ApiForpost


class ApiV3Predictions(
    ApiForget,
    ApiForpost,
):
    pass
