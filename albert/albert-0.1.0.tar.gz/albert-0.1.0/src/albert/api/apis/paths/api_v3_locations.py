from albert.api.paths.api_v3_locations.get import ApiForget
from albert.api.paths.api_v3_locations.post import ApiForpost


class ApiV3Locations(
    ApiForget,
    ApiForpost,
):
    pass
