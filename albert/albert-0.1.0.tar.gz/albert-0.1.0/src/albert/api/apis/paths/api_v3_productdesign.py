from albert.api.paths.api_v3_productdesign.get import ApiForget
from albert.api.paths.api_v3_productdesign.post import ApiForpost


class ApiV3Productdesign(
    ApiForget,
    ApiForpost,
):
    pass
