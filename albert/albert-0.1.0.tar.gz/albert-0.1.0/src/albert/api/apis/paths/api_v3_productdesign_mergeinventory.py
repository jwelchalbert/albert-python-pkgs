from albert.api.paths.api_v3_productdesign_mergeinventory.post import ApiForpost


class ApiV3ProductdesignMergeinventory(
    ApiForpost,
):
    pass
