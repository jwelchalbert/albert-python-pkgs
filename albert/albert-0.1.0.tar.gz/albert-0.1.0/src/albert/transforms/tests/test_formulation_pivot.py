from sklearn.utils.estimator_checks import parametrize_with_checks

from albert.transforms.formulation_transforms import FormulationPivot

# @parametrize_with_checks([FormulationPivot()])
# def test_sklearn_compatible_transform(estimator, check):
#     check(estimator)
