from albert.api.paths.api_v3_reports_copy.post import ApiForpost


class ApiV3ReportsCopy(
    ApiForpost,
):
    pass
