from albert.api.paths.api_v3_reports_inventory_movements.get import ApiForget


class ApiV3ReportsInventoryMovements(
    ApiForget,
):
    pass
