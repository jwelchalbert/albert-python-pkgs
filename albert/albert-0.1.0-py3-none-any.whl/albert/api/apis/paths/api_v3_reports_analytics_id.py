from albert.api.paths.api_v3_reports_analytics_id.get import ApiForget


class ApiV3ReportsAnalyticsId(
    ApiForget,
):
    pass
