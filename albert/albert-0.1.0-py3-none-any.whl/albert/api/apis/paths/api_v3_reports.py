from albert.api.paths.api_v3_reports.get import ApiForget
from albert.api.paths.api_v3_reports.post import ApiForpost


class ApiV3Reports(
    ApiForget,
    ApiForpost,
):
    pass
