from albert.api.paths.api_v3_reports_health.get import ApiForget


class ApiV3ReportsHealth(
    ApiForget,
):
    pass
