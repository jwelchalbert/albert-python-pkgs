from albert.api.paths.api_v3_predictions_models_parent_id_version_id.get import ApiForget


class ApiV3PredictionsModelsParentIdVersionId(
    ApiForget,
):
    pass
