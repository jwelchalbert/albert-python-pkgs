from albert.api.paths.api_v3_productdesign_suggest.get import ApiForget


class ApiV3ProductdesignSuggest(
    ApiForget,
):
    pass
