from albert.api.paths.api_v3_inventories_health.get import ApiForget


class ApiV3InventoriesHealth(
    ApiForget,
):
    pass
