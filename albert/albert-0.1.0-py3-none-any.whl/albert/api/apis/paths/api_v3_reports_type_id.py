from albert.api.paths.api_v3_reports_type_id.get import ApiForget


class ApiV3ReportsTypeId(
    ApiForget,
):
    pass
