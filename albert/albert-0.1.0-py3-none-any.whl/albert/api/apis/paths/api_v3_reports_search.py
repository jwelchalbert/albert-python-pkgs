from albert.api.paths.api_v3_reports_search.get import ApiForget


class ApiV3ReportsSearch(
    ApiForget,
):
    pass
