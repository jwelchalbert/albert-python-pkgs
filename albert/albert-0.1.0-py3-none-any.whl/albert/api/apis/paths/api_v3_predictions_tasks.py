from albert.api.paths.api_v3_predictions_tasks.post import ApiForpost


class ApiV3PredictionsTasks(
    ApiForpost,
):
    pass
