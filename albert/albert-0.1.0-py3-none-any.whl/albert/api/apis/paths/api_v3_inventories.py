from albert.api.paths.api_v3_inventories.get import ApiForget
from albert.api.paths.api_v3_inventories.post import ApiForpost


class ApiV3Inventories(
    ApiForget,
    ApiForpost,
):
    pass
