from albert.api.paths.api_v3_predictions_models_id.get import ApiForget


class ApiV3PredictionsModelsId(
    ApiForget,
):
    pass
