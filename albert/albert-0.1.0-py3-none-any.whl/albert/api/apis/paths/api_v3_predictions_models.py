from albert.api.paths.api_v3_predictions_models.get import ApiForget
from albert.api.paths.api_v3_predictions_models.post import ApiForpost


class ApiV3PredictionsModels(
    ApiForget,
    ApiForpost,
):
    pass
