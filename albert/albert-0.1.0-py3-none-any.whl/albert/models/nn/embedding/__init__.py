# pylama:skip=1
from .mlp import MLPEmbedding
